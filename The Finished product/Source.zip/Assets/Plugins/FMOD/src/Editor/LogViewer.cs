/* This class is now legacy. Keep the definition here for the migration to work */
using UnityEditor;

public class LogViewer : EditorWindow
{
}